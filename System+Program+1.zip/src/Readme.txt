1. Compile openwrt_server using Openwrt cross-compile (can config PORT, IP in source file)
   Compile show_server using normal C compile (can config PORT, IP in source file)

2. Copy compiled openwrt_server and all .html files to Buffalo router (same folder) then run "./openwrt_server"

3. Copy compiled show_server to virtual sever then run "./show_server" 
