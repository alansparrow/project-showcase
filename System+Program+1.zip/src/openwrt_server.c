#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#define CONNMAX 1000
#define BYTES 1024
#define DB_HOST "54.178.195.55"
#define ATTD_LINK "http://54.178.195.55:8000"
#define DB_PORT 10000
#define HTML_HEADER "header.html"
#define HTML_FOOTER "footer.html"

char *ROOT;
int listenfd, clients[CONNMAX];
void error(char *);
void startServer(char *);
void respond(int);
void cmd_exec(char *[], int);
void utf_to_ascii(char *);
void urldecode(char *, char *, char *);
inline int ishex(int);
int decode(const char *, char *);
char *getmacaddr(char *ipaddr);
void check_studentMACAddr(char *studentMACAddr);
void register_student(char *, char *, char *);
void check_attendance(char *);
void add_attendance(char *);

void send_html_header(int fd);
void send_html_footer(int fd);
void send_register_page(int fd);
void send_notice(int client_fd, char *notice);
void send_error(int client_fd, char *err_msg);
void send_check_attendance_page(int client_fd, char *sName, char *sID);
void send_checked_attendance_page(int client_fd, char *sName, char *sID);
int decodeContent(char *, char *);

int tokenizeUrl(char *url);

int replyID;
char *studentName, *studentID, *studentMACAddr, *replyMsg;
char *tokenizedParam[20];
char *macAddr;
 
int main(int argc, char* argv[])
{
  struct sockaddr_in clientaddr;
  socklen_t addrlen;
  char c;
  //Default Values PATH = ~/ and PORT=10000
  char PORT[6];
  ROOT = getenv("PWD");
  strcpy(PORT,"10001");
 
  int slot=0;
 
  //Parsing the command line arguments
  while ((c = getopt (argc, argv, "p:r:")) != -1)
    switch (c)
      {
      case 'r':
	ROOT = malloc(strlen(optarg));
	strcpy(ROOT,optarg);
	break;
      case 'p':
	strcpy(PORT,optarg);
	break;
      case '?':
	fprintf(stderr,"Wrong arguments given!!!\n");
	exit(1);
      default:
	exit(1);
      }
  printf("Server started at port no. %s%s%s with root directory as %s%s%s\n","\033[92m",PORT,"\033[0m","\033[92m",ROOT,"\033[0m");
  // Setting all elements to -1: signifies there is no client connected
  int i;
  for (i=0; i<CONNMAX; i++)
    clients[i]=-1;
  startServer(PORT);
 
  // ACCEPT connections
  while (1)
    {
      addrlen = sizeof(clientaddr);
      clients[slot] = accept (listenfd, (struct sockaddr *) &clientaddr, &addrlen);
 
      if (clients[slot]<0)
	error ("accept() error");
      else
	{
	  if ( fork()==0 )
	    {
	      printf("Client info:\n");
	      printf("     %s:%d\n", inet_ntoa(clientaddr.sin_addr),
		     (int) ntohs(clientaddr.sin_port));

	      // Get MAC addr and check 
	      macAddr = getmacaddr(inet_ntoa(clientaddr.sin_addr));
	      printf("\nMac Addr: %s\n", macAddr);
	      check_studentMACAddr(macAddr);

	      respond(slot);
	      exit(0);
	    }
	}
 
      while (clients[slot]!=-1) slot = (slot+1)%CONNMAX;
    }
 
  return 0;
}
 
//start server
void startServer(char *port)
{
  struct addrinfo hints, *res, *p;
 
  // getaddrinfo for host
  memset (&hints, 0, sizeof(hints));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;
  if (getaddrinfo( NULL, port, &hints, &res) != 0)
    {
      perror ("getaddrinfo() error");
      exit(1);
    }
  // socket and bind
  for (p = res; p!=NULL; p=p->ai_next)
    {
      listenfd = socket (p->ai_family, p->ai_socktype, 0);
      if (listenfd == -1) continue;
      if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) break;
    }
  if (p==NULL)
    {
      perror ("socket() or bind()");
      exit(1);
    }
 
  freeaddrinfo(res);
 
  // listen for incoming connections
  if ( listen (listenfd, 1000000) != 0 )
    {
      perror("listen() error");
      exit(1);
    }
}
 
//client connection
void respond(int n)
{
  char mesg[99999], *reqline[3], data_to_send[BYTES], path[99999],html[99999],*param[3], *target,*result;
  int rcvd, fd, bytes_read, tmp_fd, i, param_count;
 
  // my code
  char *reply_content, *cmd_to_execute, *err_msg, *return_rec;
  int buf_size = 10000;
  FILE *fpin, *tmp_file1;
 
  memset( (void*)mesg, (int)'\0', 99999 );
 
  rcvd=recv(clients[n], mesg, 99999, 0);
 
  if (rcvd<0) // receive error
    fprintf(stderr,("recv() error\n"));
  else if (rcvd==0) // receive socket closed
    fprintf(stderr,"Client disconnected upexpectedly.\n");
  else // message received
    {
      printf("%s", mesg);
      reqline[0] = strtok (mesg, " \t\n");
      if ( strncmp(reqline[0], "GET\0", 4)==0 )
	{
	  reqline[1] = strtok (NULL, " \t");
	  reqline[2] = strtok (NULL, " \t\n");
	  if ( strncmp( reqline[2], "HTTP/1.0", 8)!=0 && strncmp( reqline[2], "HTTP/1.1", 8)!=0 )
	    {
	      write(clients[n], "HTTP/1.0 400 Bad Request\n", 25);
	    }
	  else
	    {
	      printf("reqline[1]: %s\n", reqline[1]);
	      
	      param[0] = strdup(reqline[1]);
	      result = (char *) malloc(sizeof(char) * strlen(param[0]));
	      decode(param[0], result);

	      if ((param_count = tokenizeUrl(reqline[1])) == 0) {
		printf("Error: parameter error.\n");
	      } else {
		for (i = 1; i <= param_count; i++)
		  printf("\n%s\n", tokenizedParam[i]);
	      }

	      send_html_header(clients[n]);


	      if (replyID == 0) {
		printf("\nCheck MACAddr: passed\n");
		
		check_attendance(macAddr);
		
		if (replyID == 0) { // OK
		  send_checked_attendance_page(clients[n], studentName, studentID);
		} else {
	
		  // Send check page

		  if (param_count >= 1 && strcmp("check_me", tokenizedParam[1]) == 0) {
		    add_attendance(macAddr);

		    if (replyID == 0) { // OK
		      send_notice(clients[n], "Congratulation! You have successfully checked your attendance.");
		      send_checked_attendance_page(clients[n], studentName, studentID);
		    } else { // Failed
		      send_error(clients[n], replyMsg);
		      send_check_attendance_page(clients[n], studentName, studentID);
		    }
		  } else { // temp
		    send_check_attendance_page(clients[n], studentName, studentID);
		  }
		} 
	      } else if (replyID == 1) {
		
		printf("\nCheck MACAddr: failed\n");
		
		// Send register page
		if (strncmp(reqline[1], "/\0", 2) == 0) {
		  send_register_page(clients[n]);
		} else if (param_count == 5 && strcmp("reg_me", tokenizedParam[1]) == 0) {
		  // Process if name is encoded
		  char *dupSName = strdup(tokenizedParam[3]);
		  char *decodedContent = (char *) malloc(sizeof(char) * buf_size);
		  decodeContent(dupSName, decodedContent);
		  
		  printf("strlen (param vs decode): %d:%d", strlen(tokenizedParam[3]), strlen(decodedContent));
		  
		  if (strlen(decodedContent) == 1) { // not encoded
		    register_student(tokenizedParam[3], tokenizedParam[5], macAddr);
		  } else { // encoded
		    register_student(decodedContent, tokenizedParam[5], macAddr);
		  }

		  if (replyID == 0) { // OK
		    send_notice(clients[n], "Congratulation! You have successfully registered.");
		    send_check_attendance_page(clients[n], studentName, studentID);
		  } else { // Failed
		    send_error(clients[n], replyMsg);
		    send_register_page(clients[n]);
		  }
		} else { // temp
		  send_error(clients[n], "Error in passing parameters.");
		  send_register_page(clients[n]);
		}
	      } else {
		printf("\nUnknown error\n");
	      }


	      send_html_footer(clients[n]);
	    }
	}
    }

  //Closing SOCKET
  shutdown (clients[n], SHUT_RDWR);
  close(clients[n]);
  clients[n]=-1;
}
void urldecode(char *src, char *last, char *dest) {
  for(;src<=last;src++,dest++){
    if(*src=='%'){
      int code;
      if(sscanf(src+1, "%2x", &code)!=1) code='?';
      *dest = code;
      src+=2;
    }else if(*src=='+') {
      *dest = ' ';
    }else {
      *dest = *src;
    }
  }
  *(++dest) = '\0';
}
 
 
inline int ishex(int x)
{
  return(x >= '0' && x <= '9')||
    (x >= 'a' && x <= 'f')||
    (x >= 'A' && x <= 'F');
}
int decode(const char *s, char *dec)
{
  char *o;
  const char *end = s + strlen(s);
  int c;
  for (o = dec; s <= end; o++) {
    c = *s++;
    if (c == '+') c = ' ';
    else if (c == '%' && (!ishex(*s++)||
			  !ishex(*s++)||
			  !sscanf(s - 2, "%2x", &c)))
      return -1;
    if (dec) *o = c;
  }
  return o - dec;
}


char *getmacaddr(char *ipaddr)
{
  FILE *fpin;
  char *reply_content;
  char *found = NULL;
  char *token;
  int count = 0;
  int buf_size = 99999;

  // cannot run 'arp' so using this instead
  if ((fpin = popen("cat /proc/net/arp", "r")) == NULL) {
    printf("ARP error!\n");
    exit(0);
  }
  reply_content = (char *) malloc(sizeof(char) * buf_size);

  while (fgets(reply_content, buf_size, fpin)) {
    if (strstr(reply_content, ipaddr) != NULL) {
      count++;
      token = strtok(reply_content, " ");

      if (strcmp(token, ipaddr) == 0)
	while (token != NULL) {
	  //printf("\n     %d: %s\n", count, token);
	  // Get MAC addr
	  if (count == 4) {
	    return token;
	  }

	  token = strtok(NULL, " ");
	  count++;
	}
    }
    
    count = 0;
    token = NULL;
  }
  
  pclose(fpin);

  return NULL;
}

void check_studentMACAddr(char *sMACAddr)
{
  struct sockaddr_in addr, cl_addr;    
  int sockfd, ret;    
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);
  char *token;
  int count = 0;

  // Init all
  replyID = -1;
  replyMsg = "Error: cannot communicate with server";
  studentName = NULL;
  studentID = NULL;
  studentMACAddr = NULL;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);    
  if (sockfd < 0) {    
    printf("Error creating socket!\n");    
    exit(1);    
  }    
  printf("Socket created...\n");     
  
  memset(&addr, 0, sizeof(addr));    
  addr.sin_family = AF_INET;    
  addr.sin_addr.s_addr = inet_addr(DB_HOST);  
  addr.sin_port = htons(DB_PORT);

  printf("Conneting to %s:%d\n", DB_HOST, DB_PORT);
  
  ret = connect(sockfd, (struct sockaddr *) &addr, sizeof(addr));    

  if (ret < 0) {    
    printf("Error connecting to the server!\n");    
    printf("Error: %s\n", strerror(errno));
    exit(1);    
  }    
  printf("Connected to the server...\n");    
  
  memset(content, 0, buf_size);
  // Create a Frame
  snprintf(content, buf_size, "%d-----%s-----%s-----%s\n", 1, "xxx", "xxx", sMACAddr);
  // Send Frame
  ret = sendto(sockfd, content, buf_size, 0, (struct sockaddr *) &addr, sizeof(addr));    
  if (ret < 0) {    
    printf("Error sending data!\n\t-%s", content);    
  } else {
    memset(content, 0, buf_size);
    // Receive reply
    ret = recvfrom(sockfd, content, buf_size, 0, NULL, NULL);
    if (ret < 0) {
      printf("Error receiving data!\n");
    } else {

      printf("\nReceived: ");
      fputs(content, stdout);

      count++;
      token = strtok(content, "-----");
      replyID = atoi(token);

      while (token != NULL) {
	token = strtok(NULL, "-----");
	count++;
	
	switch (count) {
	case 2: // Return Msg
	  replyMsg = token;
	  break;
	case 3: // Name
	  studentName = token;
	  break;
	case 4: // StudentID
	  studentID = token;
	  break;
	case 5: // MAC addr
	  studentMACAddr = token;
	  break;
	}
      }
    }
  }
  
  close(sockfd);  

}

void check_attendance(char *sMACAddr)
{
  struct sockaddr_in addr, cl_addr;    
  int sockfd, ret;    
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);
  char *token;
  int count = 0;

  // Init all
  replyID = -1;
  replyMsg = "Error: cannot communicate with server.";
  studentName = NULL;
  studentID = NULL;
  studentMACAddr = NULL;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);    
  if (sockfd < 0) {    
    printf("Error creating socket!\n");    
    exit(1);    
  }    
  printf("Socket created...\n");     
  
  memset(&addr, 0, sizeof(addr));    
  addr.sin_family = AF_INET;    
  addr.sin_addr.s_addr = inet_addr(DB_HOST);  
  addr.sin_port = htons(DB_PORT);

  printf("Conneting to %s:%d\n", DB_HOST, DB_PORT);
  
  ret = connect(sockfd, (struct sockaddr *) &addr, sizeof(addr));    

  if (ret < 0) {    
    printf("Error connecting to the server!\n");    
    printf("Error: %s\n", strerror(errno));
    exit(1);    
  }    
  printf("Connected to the server...\n");    
  
  memset(content, 0, buf_size);
  // Create a Frame
  snprintf(content, buf_size, "%d-----%s-----%s-----%s\n", 2, "xxx", "xxx", sMACAddr);
  // Send Frame
  ret = sendto(sockfd, content, buf_size, 0, (struct sockaddr *) &addr, sizeof(addr));    
  if (ret < 0) {    
    printf("Error sending data!\n\t-%s", content);    
  } else {
    memset(content, 0, buf_size);
    // Receive reply
    ret = recvfrom(sockfd, content, buf_size, 0, NULL, NULL);
    if (ret < 0) {
      printf("Error receiving data!\n");
    } else {

      printf("\nReceived: ");
      fputs(content, stdout);

      count++;
      token = strtok(content, "-----");
      replyID = atoi(token);

      while (token != NULL) {
	token = strtok(NULL, "-----");
	count++;
	
	switch (count) {
	case 2: // Return Msg
	  replyMsg = token;
	  break;
	case 3: // Name
	  studentName = token;
	  break;
	case 4: // StudentID
	  studentID = token;
	  break;
	case 5: // MAC addr
	  studentMACAddr = token;
	  break;
	}
      }
    }
  }
  
  close(sockfd);  

}

void add_attendance(char *sMACAddr)
{
  struct sockaddr_in addr, cl_addr;    
  int sockfd, ret;    
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);
  char *token;
  int count = 0;

  // Init all
  replyID = -1;
  replyMsg = "Error: cannot communicate with server.";
  studentName = NULL;
  studentID = NULL;
  studentMACAddr = NULL;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);    
  if (sockfd < 0) {    
    printf("Error creating socket!\n");    
    exit(1);    
  }    
  printf("Socket created...\n");     
  
  memset(&addr, 0, sizeof(addr));    
  addr.sin_family = AF_INET;    
  addr.sin_addr.s_addr = inet_addr(DB_HOST);  
  addr.sin_port = htons(DB_PORT);

  printf("Conneting to %s:%d\n", DB_HOST, DB_PORT);
  
  ret = connect(sockfd, (struct sockaddr *) &addr, sizeof(addr));    

  if (ret < 0) {    
    printf("Error connecting to the server!\n");    
    printf("Error: %s\n", strerror(errno));
    exit(1);    
  }    
  printf("Connected to the server...\n");    
  
  memset(content, 0, buf_size);
  // Create a Frame
  snprintf(content, buf_size, "%d-----%s-----%s-----%s\n", 3, "xxx", "xxx", sMACAddr);
  // Send Frame
  ret = sendto(sockfd, content, buf_size, 0, (struct sockaddr *) &addr, sizeof(addr));    
  if (ret < 0) {    
    printf("Error sending data!\n\t-%s", content);    
  } else {
    memset(content, 0, buf_size);
    // Receive reply
    ret = recvfrom(sockfd, content, buf_size, 0, NULL, NULL);
    if (ret < 0) {
      printf("Error receiving data!\n");
    } else {

      printf("\nReceived: ");
      fputs(content, stdout);

      count++;
      token = strtok(content, "-----");
      replyID = atoi(token);

      while (token != NULL) {
	token = strtok(NULL, "-----");
	count++;
	
	switch (count) {
	case 2: // Return Msg
	  replyMsg = token;
	  break;
	case 3: // Name
	  studentName = token;
	  break;
	case 4: // StudentID
	  studentID = token;
	  break;
	case 5: // MAC addr
	  studentMACAddr = token;
	  break;
	}
      }
    }
  }
  
  close(sockfd);  

}



void register_student(char *sName, char *sID, char *sMACAddr)
{
  struct sockaddr_in addr, cl_addr;    
  int sockfd, ret;    
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);
  char *token;
  int count = 0;

  // Init all
  replyID = -1;
  replyMsg = "Error: cannot communicate with server";
  studentName = NULL;
  studentID = NULL;
  studentMACAddr = NULL;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);    
  if (sockfd < 0) {    
    printf("Error creating socket!\n");    
    exit(1);    
  }    
  printf("Socket created...\n");     
  
  memset(&addr, 0, sizeof(addr));    
  addr.sin_family = AF_INET;    
  addr.sin_addr.s_addr = inet_addr(DB_HOST);  
  addr.sin_port = htons(DB_PORT);

  printf("Conneting to %s:%d\n", DB_HOST, DB_PORT);
  
  ret = connect(sockfd, (struct sockaddr *) &addr, sizeof(addr));    

  if (ret < 0) {    
    printf("Error connecting to the server!\n");    
    printf("Error: %s\n", strerror(errno));
    exit(1);    
  }    
  printf("Connected to the server...\n");    
  
  memset(content, 0, buf_size);
  // Create a Frame
  snprintf(content, buf_size, "%d-----%s-----%s-----%s\n", 9, sName, sID, sMACAddr);
  // Send Frame
  ret = sendto(sockfd, content, buf_size, 0, (struct sockaddr *) &addr, sizeof(addr));    
  if (ret < 0) {    
    printf("Error sending data!\n\t-%s", content);    
    replyID = 9; // error
    snprintf(replyMsg, buf_size, "%s", "Error: Cannot send request to server.");
  } else {
    memset(content, 0, buf_size);
    // Receive reply
    ret = recvfrom(sockfd, content, buf_size, 0, NULL, NULL);
    if (ret < 0) {
      printf("Error receiving data!\n");
    } else {

      printf("\nReceived: ");
      fputs(content, stdout);

      count++;
      token = strtok(content, "-----");
      replyID = atoi(token);

      while (token != NULL) {
	token = strtok(NULL, "-----");
	count++;
	
	switch (count) {
	case 2: // Return Msg
	  replyMsg = token;
	  break;
	case 3: // Name
	  studentName = token;
	  break;
	case 4: // StudentID
	  studentID = token;
	  break;
	case 5: // MAC addr
	  studentMACAddr = token;
	  break;
	}
      }
    }
  }
  
  close(sockfd);  

}


void send_html_header(int client_fd)
{
  char *data_to_send;
  int rcvd, fd, bytes_read, tmp_fd;
  
  data_to_send = (char *) malloc(sizeof(char) * BYTES);

  if ((fd=open(HTML_HEADER, O_RDONLY)) != -1) {
    write(client_fd, "HTTP/1.0 200 OK\n\n", 17);
    while ((bytes_read = read(fd, data_to_send, BYTES))>0 ) {
      write (client_fd, data_to_send, bytes_read);
      //printf("%s", data_to_send);
    }
  }
}


void send_html_footer(int client_fd)
{
  char *data_to_send;
  int rcvd, fd, bytes_read, tmp_fd;
  
  data_to_send = (char *) malloc(sizeof(char) * BYTES);

  if ((fd=open(HTML_FOOTER, O_RDONLY)) != -1) {
    while ((bytes_read = read(fd, data_to_send, BYTES))>0 ) {
      write (client_fd, data_to_send, bytes_read);
      //printf("%s", data_to_send);
    }
  }

}

void send_register_page(int client_fd)
{
  int buf_size = 9999;
  char *sATTDLink = (char *) malloc(sizeof(char) * buf_size);

  write(client_fd, "<form action=\"reg_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 67);
  write(client_fd, "<h2 class=\"form-signin-heading\">Please register</h2>", 52);
  write(client_fd, "<input type=\"text\" name=\"name\" class=\"form-control\" placeholder=\"Your name\" required autofocus>", 95);
  write(client_fd, "<input type=\"text\" name=\"studentid\" class=\"form-control\" placeholder=\"Your student ID\" required>", 96);

  write(client_fd, "<br>", 4);

  write(client_fd, "<button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Register</button>", 80);

  
  write(client_fd, "<br>", 4);

  snprintf(sATTDLink, buf_size, "<a class=\"btn btn-sm btn-primary btn-block\" href=\"%s\">Attendance Sheet</a>", ATTD_LINK);
  write(client_fd, sATTDLink, strlen(sATTDLink));

  write(client_fd, "</form>", 7);
}

void send_error(int client_fd, char *err_msg)
{
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);

  snprintf(content, buf_size, "<p>%s<p>", err_msg);
  write(client_fd, "<div class=\"alert alert-danger\">", 32);
  write(client_fd, content, strlen(content));
  write(client_fd, "</div>", 6);
}

void send_notice(int client_fd, char *notice)
{
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);

  snprintf(content, buf_size, "<p>%s<p>", notice);
  write(client_fd, "<div class=\"alert alert-success\">", 32);
  write(client_fd, content, strlen(content));
  write(client_fd, "</div>", 6);
}

void send_check_attendance_page(int client_fd, char *sName, char *sID)
{
  int buf_size = 9999;
  char *sNameContent = (char *) malloc(sizeof(char) * buf_size);
  char *sIDContent = (char *) malloc(sizeof(char) * buf_size);
  char *sATTDLink = (char *) malloc(sizeof(char) * buf_size);

  write(client_fd, "<form action=\"check_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 69);
  write(client_fd, "<h2 class=\"form-signin-heading\">Your Information</h2>", 53);
  write(client_fd, "<span class=\"label label-danger\">Not checked</span>", 51);
  
  snprintf(sNameContent, buf_size, "<input type=\"text\" name=\"name\" class=\"form-control\" id=\"disabledInput\" value=\"%s\" readonly>", sName);
  snprintf(sIDContent, buf_size, "<input type=\"text\" name=\"studentid\" class=\"form-control\" id=\"disabledInput\" value=\"%s\" readonly>", sID);
  write(client_fd, sNameContent, strlen(sNameContent));
  write(client_fd, sIDContent, strlen(sIDContent));
       
  write(client_fd, "<br>", 4);
  
  write(client_fd, "<button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Check me!</button>", 81);

  
  write(client_fd, "<br>", 4);

  snprintf(sATTDLink, buf_size, "<a class=\"btn btn-sm btn-primary btn-block\" href=\"%s\">Attendance Sheet</a>", ATTD_LINK);
  write(client_fd, sATTDLink, strlen(sATTDLink));


  write(client_fd, "</form>", 7);
}

void send_checked_attendance_page(int client_fd, char *sName, char *sID)
{
  int buf_size = 9999;
  char *sNameContent = (char *) malloc(sizeof(char) * buf_size);
  char *sIDContent = (char *) malloc(sizeof(char) * buf_size);
  char *sATTDLink = (char *) malloc(sizeof(char) * buf_size);

  write(client_fd, "<form action=\"check_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 69);
  write(client_fd, "<h2 class=\"form-signin-heading\">Your Information</h2>", 53);
  write(client_fd, "<span class=\"label label-success\">Checked</span>", 51);
  
  snprintf(sNameContent, buf_size, "<input type=\"text\" name=\"name\" class=\"form-control\" value=\"%s\" readonly>", sName);
  snprintf(sIDContent, buf_size, "<input type=\"text\" name=\"studentid\" class=\"form-control\" value=\"%s\" readonly>", sID);
  write(client_fd, sNameContent, strlen(sNameContent));
  write(client_fd, sIDContent, strlen(sIDContent));
  
  write(client_fd, "<br>", 4);

  snprintf(sATTDLink, buf_size, "<a class=\"btn btn-sm btn-primary btn-block\" href=\"%s\">Attendance Sheet</a>", ATTD_LINK);
  write(client_fd, sATTDLink, strlen(sATTDLink));
  
  write(client_fd, "</form>", 7);
}

int tokenizeUrl(char *url)
{
  int count = 0;
  char *token = NULL;
  char *result = (char *) malloc(sizeof(char) * strlen(url));
  
  strcpy(result, url);
  //decode(url, result);
  
  
  //  printf("Tokenizing: %s\n", result);
  token = strtok(result, "/?=&");

  if (token == NULL)
    return 0;
  count++;
  tokenizedParam[count] = token;
  
  while (token != NULL) {
    //printf("%d: %s\n", count, token);
    token = strtok(NULL, "/?=&");
    count++;
    tokenizedParam[count] = token;
  }
  
  // Cancel last one which is NULL
  count--;

  return count;
}

int decodeContent(char *in, char *out)
{
  char *token;
  int c;

  token = strtok(in, "%");

  if (token == NULL)
    return -1;

  while (token != NULL) {
    sscanf(token, "%X", &c);

    if (c > 0xFF)
      return -1;

    *out++ = c;

    token = strtok(NULL, "%");
  }

  *out = '\0';

  return 0;
}
