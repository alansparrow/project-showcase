#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#define CONNMAX 1000
#define BYTES 1024
#define DB_HOST "54.178.195.55"
#define DB_PORT 10000
#define HTML_HEADER "header.html"
#define HTML_FOOTER "footer.html"
#define S_RECORD "student_record.data"
#define A_RECORD "attendance_record.data"

char *ROOT;
int listenfd, clients[CONNMAX];
void error(char *);
void startServer(char *);
void respond(int);
void cmd_exec(char *[], int);
void utf_to_ascii(char *);
void urldecode(char *, char *, char *);
inline int ishex(int);
int decode(const char *, char *);
char *getmacaddr(char *ipaddr);
void check_studentMACAddr(char *studentMACAddr);
void register_student(char *, char *, char *);
char * check_attendance(char *);
void add_attendance(char *);

void send_html_header(int fd);
void send_html_footer(int fd);
void send_table_header(int fd);
void send_table_footer(int fd);
void send_register_page(int fd);
void send_notice(int client_fd, char *notice);
void send_error(int client_fd, char *err_msg);
void send_check_attendance_page(int client_fd, char *sName, char *sID);
void send_checked_attendance_page(int client_fd, char *sName, char *sID);
void send_student_record(int client_fd, int index, char *sName, char *sID, char *sMACAddr);
void send_student_records(int client_fd);
int decodeContent(char *, char *);

int tokenizeUrl(char *url);

int replyID;
char *studentName, *studentID, *studentMACAddr, *replyMsg;
char *tokenizedParam[20];
char *macAddr;
 
int main(int argc, char* argv[])
{
  struct sockaddr_in clientaddr;
  socklen_t addrlen;
  char c;
  //Default Values PATH = ~/ and PORT=10000
  char PORT[6];
  ROOT = getenv("PWD");
  strcpy(PORT,"8000");
 
  int slot=0;
 
  //Parsing the command line arguments
  while ((c = getopt (argc, argv, "p:r:")) != -1)
    switch (c)
      {
      case 'r':
	ROOT = malloc(strlen(optarg));
	strcpy(ROOT,optarg);
	break;
      case 'p':
	strcpy(PORT,optarg);
	break;
      case '?':
	fprintf(stderr,"Wrong arguments given!!!\n");
	exit(1);
      default:
	exit(1);
      }
  printf("Server started at port no. %s%s%s with root directory as %s%s%s\n","\033[92m",PORT,"\033[0m","\033[92m",ROOT,"\033[0m");
  // Setting all elements to -1: signifies there is no client connected
  int i;
  for (i=0; i<CONNMAX; i++)
    clients[i]=-1;
  startServer(PORT);
 
  // ACCEPT connections
  while (1)
    {
      addrlen = sizeof(clientaddr);
      clients[slot] = accept (listenfd, (struct sockaddr *) &clientaddr, &addrlen);
 
      if (clients[slot]<0)
	error ("accept() error");
      else
	{
	  if ( fork()==0 )
	    {
	      respond(slot);
	      exit(0);
	    }
	}
 
      while (clients[slot]!=-1) slot = (slot+1)%CONNMAX;
    }
 
  return 0;
}
 
//start server
void startServer(char *port)
{
  struct addrinfo hints, *res, *p;
 
  // getaddrinfo for host
  memset (&hints, 0, sizeof(hints));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;
  if (getaddrinfo( NULL, port, &hints, &res) != 0)
    {
      perror ("getaddrinfo() error");
      exit(1);
    }
  // socket and bind
  for (p = res; p!=NULL; p=p->ai_next)
    {
      listenfd = socket (p->ai_family, p->ai_socktype, 0);
      if (listenfd == -1) continue;
      if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) break;
    }
  if (p==NULL)
    {
      perror ("socket() or bind()");
      exit(1);
    }
 
  freeaddrinfo(res);
 
  // listen for incoming connections
  if ( listen (listenfd, 1000000) != 0 )
    {
      perror("listen() error");
      exit(1);
    }
}
 
//client connection
void respond(int n)
{
  char mesg[99999], *reqline[3], data_to_send[BYTES], path[99999],html[99999],*param[3], *target,*result;
  int rcvd, fd, bytes_read, tmp_fd, i, param_count;
 
  // my code
  char *reply_content, *cmd_to_execute, *err_msg, *return_rec;
  int buf_size = 10000;
  FILE *fpin, *tmp_file1;
 
  memset( (void*)mesg, (int)'\0', 99999 );
 
  rcvd=recv(clients[n], mesg, 99999, 0);
 
  if (rcvd<0) // receive error
    fprintf(stderr,("recv() error\n"));
  else if (rcvd==0) // receive socket closed
    fprintf(stderr,"Client disconnected upexpectedly.\n");
  else // message received
    {
      printf("%s", mesg);
      reqline[0] = strtok (mesg, " \t\n");
      if ( strncmp(reqline[0], "GET\0", 4)==0 )
	{
	  reqline[1] = strtok (NULL, " \t");
	  reqline[2] = strtok (NULL, " \t\n");
	  if ( strncmp( reqline[2], "HTTP/1.0", 8)!=0 && strncmp( reqline[2], "HTTP/1.1", 8)!=0 )
	    {
	      write(clients[n], "HTTP/1.0 400 Bad Request\n", 25);
	    }
	  else
	    {
	      printf("reqline[1]: %s\n", reqline[1]);
	      
	      send_html_header(clients[n]);
	      send_table_header(clients[n]);
	      send_student_records(clients[n]);
	      send_table_footer(clients[n]);
	      send_html_footer(clients[n]);
	    }
	}
    }

  //Closing SOCKET
  shutdown (clients[n], SHUT_RDWR);
  close(clients[n]);
  clients[n]=-1;
}
void urldecode(char *src, char *last, char *dest) {
  for(;src<=last;src++,dest++){
    if(*src=='%'){
      int code;
      if(sscanf(src+1, "%2x", &code)!=1) code='?';
      *dest = code;
      src+=2;
    }else if(*src=='+') {
      *dest = ' ';
    }else {
      *dest = *src;
    }
  }
  *(++dest) = '\0';
}
 
 
inline int ishex(int x)
{
  return(x >= '0' && x <= '9')||
    (x >= 'a' && x <= 'f')||
    (x >= 'A' && x <= 'F');
}
int decode(const char *s, char *dec)
{
  char *o;
  const char *end = s + strlen(s);
  int c;
  for (o = dec; s <= end; o++) {
    c = *s++;
    if (c == '+') c = ' ';
    else if (c == '%' && (!ishex(*s++)||
			  !ishex(*s++)||
			  !sscanf(s - 2, "%2x", &c)))
      return -1;
    if (dec) *o = c;
  }
  return o - dec;
}


void send_html_attendance_table(int client_fd)
{

}

void send_html_header(int client_fd)
{
  char *data_to_send;
  int rcvd, fd, bytes_read, tmp_fd;
  
  data_to_send = (char *) malloc(sizeof(char) * BYTES);

  if ((fd=open(HTML_HEADER, O_RDONLY)) != -1) {
    write(client_fd, "HTTP/1.0 200 OK\n\n", 17);
    while ((bytes_read = read(fd, data_to_send, BYTES))>0 ) {
      write (client_fd, data_to_send, bytes_read);
      //printf("%s", data_to_send);
    }
  }
}


void send_html_footer(int client_fd)
{
  char *data_to_send;
  int rcvd, fd, bytes_read, tmp_fd;
  
  data_to_send = (char *) malloc(sizeof(char) * BYTES);

  if ((fd=open(HTML_FOOTER, O_RDONLY)) != -1) {
    while ((bytes_read = read(fd, data_to_send, BYTES))>0 ) {
      write (client_fd, data_to_send, bytes_read);
      //printf("%s", data_to_send);
    }
  }

}

void send_register_page(int client_fd)
{
  write(client_fd, "<form action=\"reg_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 67);
  write(client_fd, "<h2 class=\"form-signin-heading\">Please register</h2>", 52);
  write(client_fd, "<input type=\"text\" name=\"name\" class=\"form-control\" placeholder=\"Your name\" required autofocus>", 95);
  write(client_fd, "<input type=\"text\" name=\"studentid\" class=\"form-control\" placeholder=\"Your student ID\" required>", 96);
  write(client_fd, "<button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Register</button>", 80);
  write(client_fd, "</form>", 7);
}

void send_error(int client_fd, char *err_msg)
{
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);

  snprintf(content, buf_size, "<p>%s<p>", err_msg);
  write(client_fd, "<div class=\"alert alert-danger\">", 32);
  write(client_fd, content, strlen(content));
  write(client_fd, "</div>", 6);
}

void send_notice(int client_fd, char *notice)
{
  int buf_size = 9999;
  char *content = (char *) malloc(sizeof(char) * buf_size);

  snprintf(content, buf_size, "<p>%s<p>", notice);
  write(client_fd, "<div class=\"alert alert-success\">", 32);
  write(client_fd, content, strlen(content));
  write(client_fd, "</div>", 6);
}

void send_check_attendance_page(int client_fd, char *sName, char *sID)
{
  int buf_size = 9999;
  char *sNameContent = (char *) malloc(sizeof(char) * buf_size);
  char *sIDContent = (char *) malloc(sizeof(char) * buf_size);
  
  write(client_fd, "<form action=\"check_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 69);
  write(client_fd, "<h2 class=\"form-signin-heading\">Your Information</h2>", 53);
  write(client_fd, "<span class=\"label label-danger\">Not checked</span>", 51);
  
  snprintf(sNameContent, buf_size, "<input type=\"text\" name=\"name\" class=\"form-control\" id=\"disabledInput\" value=\"%s\" readonly>", sName);
  snprintf(sIDContent, buf_size, "<input type=\"text\" name=\"studentid\" class=\"form-control\" id=\"disabledInput\" value=\"%s\" readonly>", sID);
  write(client_fd, sNameContent, strlen(sNameContent));
  write(client_fd, sIDContent, strlen(sIDContent));
       
  
  write(client_fd, "<button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Check me!</button>", 81);
  write(client_fd, "</form>", 7);
}

void send_checked_attendance_page(int client_fd, char *sName, char *sID)
{
  int buf_size = 9999;
  char *sNameContent = (char *) malloc(sizeof(char) * buf_size);
  char *sIDContent = (char *) malloc(sizeof(char) * buf_size);
  
  write(client_fd, "<form action=\"check_me\" method=\"GET\" class=\"form-signin\" role=\"form\">", 69);
  write(client_fd, "<h2 class=\"form-signin-heading\">Your Information</h2>", 53);
  write(client_fd, "<span class=\"label label-success\">Checked</span>", 51);
  
  snprintf(sNameContent, buf_size, "<input type=\"text\" name=\"name\" class=\"form-control\" value=\"%s\" readonly>", sName);
  snprintf(sIDContent, buf_size, "<input type=\"text\" name=\"studentid\" class=\"form-control\" value=\"%s\" readonly>", sID);
  write(client_fd, sNameContent, strlen(sNameContent));
  write(client_fd, sIDContent, strlen(sIDContent));
       
  
  write(client_fd, "</form>", 7);
}

int tokenizeUrl(char *url)
{
  int count = 0;
  char *token = NULL;
  char *result = (char *) malloc(sizeof(char) * strlen(url));
  
  strcpy(result, url);
  //decode(url, result);
  
  
  //  printf("Tokenizing: %s\n", result);
  token = strtok(result, "/?=&");

  if (token == NULL)
    return 0;
  count++;
  tokenizedParam[count] = token;
  
  while (token != NULL) {
    //printf("%d: %s\n", count, token);
    token = strtok(NULL, "/?=&");
    count++;
    tokenizedParam[count] = token;
  }
  
  // Cancel last one which is NULL
  count--;

  return count;
}

int decodeContent(char *in, char *out)
{
  char *token;
  int c;

  token = strtok(in, "%");

  if (token == NULL)
    return -1;

  while (token != NULL) {
    sscanf(token, "%X", &c);

    if (c > 0xFF)
      return -1;

    *out++ = c;

    token = strtok(NULL, "%");
  }

  *out = '\0';

  return 0;
}


void send_student_records(int client_fd)
{
  FILE *f = fopen(S_RECORD, "r");
  char *rec, *saved_rec, *token;
  int buf_size = 9999;
  int count = 0;
  int index = 0;

  if (f == NULL)
    return NULL;

  rec = (char *) malloc(sizeof(char) * buf_size);


  while (fgets(rec, buf_size, f)) {
      // copy record for return
      saved_rec = (char *) malloc(sizeof(char) * buf_size);
      strcpy(saved_rec, rec);
      count = 0;

      count++;
      token = strtok(rec, "-----");
      
      while (token != NULL) {
	switch (count) {
	case 1: // Name
	  studentName = token;
	case 2: // ID
	  studentID = token;
	  break;
	case 3: // MAC
	  studentMACAddr = token;
	  break;
	}
	token = strtok(NULL, "-----");
	count++;
      }
      
      count--;
      
      if (strstr(studentName, "\n") == NULL && strstr(studentID, "\n") == NULL) {
	printf("Notice: ok record.\n");
	printf("%s-----%s-----%s\n", studentName, studentID, studentMACAddr);
      } else {
	printf("Error: empty record.\n");
	continue;
      }
      
      index++;
      send_student_record(client_fd, index, studentName, studentID, studentMACAddr);
  }

  
  fclose(f);
  return NULL;
}

void send_table_header(int client_fd)
{
  // Table head
  write(client_fd, "<table class=\"table\">", 21);
  write(client_fd, "<thead>", 7);
  write(client_fd, "<tr>", 4);
  write(client_fd, "<th>#</th>", 10);
  write(client_fd, "<th>Name</th>", 13);
  write(client_fd, "<th>Student ID</th>", 19);
  write(client_fd, "<th style=\"text-align:center;\">Attendance Status</th>", 53);
  write(client_fd, "</tr>", 5);
  write(client_fd, "</thead>", 8);
  write(client_fd, "<tbody>", 7);
}

void send_table_footer(int client_fd)
{
  // Table footer
  write(client_fd, "</tbody>", 8);
  write(client_fd, "</table>", 8);
}
void send_student_record(int client_fd, int index, char *sName, char *sID, char *sMACAddr)
{
  char *isChecked = check_attendance(sMACAddr);
  
  int buf_size = 9999;
  char *sIndexContent = (char *) malloc(sizeof(char) * buf_size);
  char *sNameContent = (char *) malloc(sizeof(char) * buf_size);
  char *sIDContent = (char *) malloc(sizeof(char) * buf_size);
  
  snprintf(sIndexContent, buf_size, "<td>%d</td>", index);
  snprintf(sNameContent, buf_size, "<td>%s</td>", sName);
  snprintf(sIDContent, buf_size, "<td>%s</td>", sID);
  
  write(client_fd, "<tr>", 4);
  write(client_fd, sIndexContent, strlen(sIndexContent));
  write(client_fd, sNameContent, strlen(sNameContent));
  write(client_fd, sIDContent, strlen(sIDContent));

  if (isChecked) {
    write(client_fd, "<td style=\"text-align:center;\"><span class=\"label label-success\">O</span></td>", 78);
  } else {
    write(client_fd, "<td style=\"text-align:center;\"><span class=\"label label-danger\">X</span></td>", 77);
  }
  
  write(client_fd, "</tr>", 5);

}


char *check_attendance(char *studentMACAddr)
{
  FILE *f = fopen(A_RECORD, "r");
  char *rec;
  int buf_size = 9999;
  
  if (f == NULL)
    return NULL;

  rec = (char *) malloc(sizeof(char) * buf_size);
  
  while (fgets(rec, buf_size, f)) {
    if (strstr(rec, studentMACAddr) != NULL)  {
      fclose(f);
      return rec;
    }
  }
  fclose(f);
  return NULL;
}
