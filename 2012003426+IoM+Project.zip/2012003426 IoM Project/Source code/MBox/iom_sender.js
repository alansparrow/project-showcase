function Sender(id, socket, mbox) {
    this.id = id;
    this.socket = socket;
    this.mbox = mbox;
}

module.exports = Sender;