function MBox(id, socket, sender, status) {
    this.id = id;
    this.socket = socket;
    this.sender = sender;
    this.status = status;
}

module.exports = MBox;