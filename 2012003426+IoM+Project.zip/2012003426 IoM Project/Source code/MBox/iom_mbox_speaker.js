var net = require('net');
var Speaker = require('speaker');
var Lame = require('lame');

var spk = null;
var decoder = null;
var host = '128.199.196.138';
var host1 = 'localhost';

var socket = new net.Socket();
socket.connect(8888, host, function() {
    console.log('Connected to server');
    socket.setTimeout(3000);

    socket.on('timeout', function() {
        socket.setTimeout(3000);
        console.log('Timeout');
        resetSpeaker();
    });



    socket.on('data', function(data) {
        try {
            if (data.toString() === 'endSong') {
                console.log('End of Song');
                resetSpeaker();
            }

            if (decoder != null) {
                decoder.write(data);
            }

        } catch (err) {
            console.log('hello holyshitt!');
        }
    });
});

function setupSpeaker() {
    console.log('Speaker is waiting...');

    spk = new Speaker({
        channels: 2,          // 2 channels
        bitDepth: 16,         // 16-bit samples
        sampleRate: 44100     // 44,100 Hz sample rate
    });

    decoder = Lame.Decoder();
    decoder.pipe(spk);
}

function removeSpeaker() {

    if (spk != null) {
        spk.end();
    }
    decoder = null;
    spk = null;
}

function resetSpeaker() {
    removeSpeaker();
    setupSpeaker();
}



