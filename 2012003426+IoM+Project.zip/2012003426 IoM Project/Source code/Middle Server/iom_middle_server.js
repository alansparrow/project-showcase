var net = require('net');
var jayson = require('jayson');
var MBox = require('./iom_mbox');
var Sender = require('./iom_sender');
var events = require('events');

var host = 'localhost';

// create a client for RPC
var rpc_client = jayson.client.http({
    port: 3000,
    hostname: host
});


/*  Virtual channel between a MBox and a Sender */
var channel = new events.EventEmitter();
channel.mbox = {};
channel.sender = {};
channel.setMaxListeners(100);

channel.on('connect', function(sender_id, mbox_id, callback){
    console.log('Sender: ' + sender_id + ' wants to connect to: ' + mbox_id);

    if (channel.sender[sender_id] != null) {
        if (channel.mbox[mbox_id] &&
            channel.mbox[mbox_id].status === 'FREE') {
            //  OK status replied
            var res_obj = {
                            status: 'OK',
                            code: 800,
                            mid: sender_id,
                            sid: mbox_id
                        };
            callback(null, JSON.stringify(res_obj));
            console.log('Accepted');

            //  Start streaming
            channel.sender[sender_id].socket.write('OK');
            channel.mbox[mbox_id].sender = channel.sender[sender_id];
            channel.sender[sender_id].mbox = channel.mbox[mbox_id];
            channel.sender[sender_id].mbox.status = 'BUSY';

            /*
            channel.sender[sender_id].socket.on('data', function(data) {
                if (channel.sender[sender_id].mbox != null &&
                    channel.sender[sender_id].mbox.socket != null) {
                    channel.sender[sender_id].mbox.socket.write(data);
                }
            });
            */
        }
        else if (channel.mbox[mbox_id] != null &&
                 channel.mbox[mbox_id].status === 'BUSY') {
            //  BUSY status replied
            var res_obj = {
                            status: 'ERROR',
                            code: 801,
                            id: 'null'
                        };
            callback(null, JSON.stringify(res_obj));
            console.log('Refused');

            //  Close connection
            if (channel.sender[sender_id].mbox != null) {
                channel.sender[sender_id].mbox.status = 'FREE';
                channel.sender[sender_id].mbox.socket.write('endSong');
            }

            channel.sender[sender_id].socket.end();
            channel.sender[sender_id].mbox = null;
            channel.sender[sender_id] = null;
            delete channel.sender[sender_id];
        } else {
            //  SERVER ERROR status replied
            callback(null, 'ERROR 802');
            console.log('Refused');
        }
    }
    else {
        //  SERVER ERROR status replied
        callback(null, 'ERROR 803');
        console.log('Refused');
    }
});





channel.on('mbox_join', function(id, socket) {
    var new_mbox = new MBox(id, socket, null, 'FREE');
    this.mbox[id] = new_mbox;
    console.log(id + ' joined on MBox Server');

    //  Send client's id
    var sender_info = {
        code: 0,
        id: id  
    };
    socket.write(JSON.stringify(sender_info));

    this.mbox[id].socket.on('error', function(err) {
        console.log(channel.mbox[id].id + ' MBox disconnected (socket error)');

        //  Close connection
        if (channel.mbox[id]) {
            if (channel.mbox[id].sender != null) {
                channel.mbox[id].sender.mbox = null;

                if (channel.mbox[id].sender.socket != null) {
                    channel.mbox[id].sender.socket.end();
                    channel.mbox[id].sender.socket.destroy();
                }
            }

            channel.mbox[id].sender = null;
            channel.mbox[id] = null;
            delete channel.mbox[id];
        }
    });

    this.mbox[id].socket.on('close', function(err) {
        console.log(channel.mbox[id].id + ' MBox disconnected (socket closed)');

        //  Close connection
        if (channel.mbox[id]) {
            if (channel.mbox[id].sender != null) {
                channel.mbox[id].sender.mbox = null;

                if (channel.mbox[id].sender.socket != null) {
                    channel.mbox[id].sender.socket.end();
                    channel.mbox[id].sender.socket.destroy();
                }
            }

            channel.mbox[id].sender = null;
            channel.mbox[id] = null;
            delete channel.mbox[id];
        }
    });
});

channel.on('sender_join', function(id, socket) {
    var new_sender = new Sender(id, socket, null);
    this.sender[id] = new_sender;
    console.log(id + ' joined on Sender Server');

    //  Send client's id
    var sender_info = {
        code: 0,
        id: id  
    };
    socket.write(JSON.stringify(sender_info));

    this.sender[id].socket.on('error', function(err) {

        console.log(id + ' Sender disconnected (socket error)');
        //  Close connection
        if (channel.sender[id]) {

            if (channel.sender[id].mbox != null) {
                channel.sender[id].mbox.status = 'FREE';

                if (channel.sender[id].mbox.socket != null) {
                    channel.sender[id].mbox.socket.write('endSong');
                }
            }

            channel.sender[id].mbox = null;
            channel.sender[id] = null;
            delete channel.sender[id];
        }
    });

    this.sender[id].socket.on('data', function(data) {
        if (channel.sender[id].mbox != null &&
            channel.sender[id].mbox.socket != null) {
            channel.sender[id].mbox.socket.write(data);
        }
    });

    this.sender[id].socket.on('close', function(err) {

        console.log(id + ' Sender disconnected (socket closed)');
        //  Close connection
        if (channel.sender[id]) {

            if (channel.sender[id].mbox != null) {
                channel.sender[id].mbox.status = 'FREE';

                if (channel.sender[id].mbox.socket != null) {
                    channel.sender[id].mbox.socket.write('endSong');
                }
            }

            channel.sender[id].mbox = null;
            channel.sender[id] = null;
            delete channel.sender[id];
        }
    });
});

/*  Server for MBox */

var mbox_server = net.createServer(function (socket) {
    var id = socket.remoteAddress + ':' + socket.remotePort;
    channel.emit('mbox_join', id, socket);
});

mbox_server.listen(8888);
console.log('MBox Server is running...');




/*  Server for Sender */

var sender_server = net.createServer(function (socket) {
    var id = socket.remoteAddress + ':' + socket.remotePort;
    channel.emit('sender_join', id, socket);
});

sender_server.listen(9999);
console.log('Sender Server is running...');


channel.on('disconnect', function(sender_id, mbox_id, callback){
    console.log('Sender: ' + sender_id + ' wants to disconnect a MBox');

    if (channel.sender[sender_id] != null && channel.sender[sender_id].mbox != null) {

        console.log('Sender: ' + sender_id + ' wants to disconnect with: ' + channel.sender[sender_id].mbox.id);
        channel.sender[sender_id].mbox.status = 'FREE';
        //channel.sender[sender_id].mbox.socket.write('endSong');
        channel.sender[sender_id].mbox = null;
        callback(null, 'OK 900');

    }
});

/* Server for connection control */
// create a RPC server
var control_server = jayson.server({
    connect: function(sender_id, mbox_id, callback) {
        channel.emit('connect', sender_id, mbox_id, callback);
    },

    list_mbox: function(callback) {
        var mbox_arr = Object.keys(channel.mbox);
        var mbox_arr_tmp = [];
        var i = 0;
        for (i = 0; i < mbox_arr.length; i++) {
            var mbox = {
                id: mbox_arr[i],
                status: channel.mbox[mbox_arr[i]].status
            };
            
            mbox_arr_tmp[i] = mbox;
        }

        var mbox_arr_list = JSON.stringify(mbox_arr_tmp);
        callback(null, mbox_arr_list);
    },

    disconnect: function(sender_id, mbox_id, callback) {
        channel.emit('disconnect', sender_id, mbox_id, callback);
    }
});

// Bind a http interface to the server and let it listen to localhost:3000
control_server.http().listen(3000);
console.log('Connection Control Server is running...');



/* Server for remote control */

var remote_control_server = net.createServer(function (socket) {

    socket.on('data', function(data) {
        try {
            var req_obj = JSON.parse(data.toString());
            var id = req_obj.myid;

            console.log(id + ' requested: ' + data);

            switch(req_obj.req_no) {
                case 1:  //  list request

                    rpc_client.request('list_mbox', [],
                                       function(err, error, response) {
                        if (err) {
                                console.log(err);
                                //throw err;
                            }
                        console.log(response); // 2!

                        var res_obj = {
                            req_no: req_obj.req_no,
                            status: 'OK',
                            data: response
                        };

                        //  Send client result msg
                        var res_obj_str = JSON.stringify(res_obj);
                        console.log('Write to client: ' + res_obj_str);
                        socket.write(res_obj_str);
                    });
                    break;
                case 2:  //  connect request

                    if (channel.sender[id] != null && 
                        channel.mbox[req_obj.partner_id] != null ) {
                        rpc_client.request('connect', [id, req_obj.partner_id], 
                                           function(err, error, response) {
                            if (err) {
                                console.log(err);
                                //throw err;
                            }
                            console.log(response); 

                            var res_obj = {
                                req_no: req_obj.req_no,
                                status: 'OK',
                                data: response
                            };

                            //  Send client result msg
                            var res_obj_str = JSON.stringify(res_obj);
                            console.log('Write to client: ' + res_obj_str);
                            socket.write(res_obj_str);
                        });    
                    }
                    break;
                case 3:  //  disconnect request
                    if (channel.sender[id] != null) {
                        rpc_client.request('disconnect', [id, req_obj.partner_id], 
                                           function(err, error, response) {
                            if (err) {
                                console.log(err);
                                //throw err;
                            }
                            console.log(response); 

                            var res_obj = {
                                req_no: req_obj.req_no,
                                status: 'OK',
                                data: response
                            };

                            //  Send client result msg
                            var res_obj_str = JSON.stringify(res_obj);
                            console.log('Write to client: ' + res_obj_str);
                            socket.write(res_obj_str);
                        });    
                    }
                    break;
                case 4:
                    break;
                default:
                    break;
            }
        } catch (err) {
            console.log('Remote Control Server: ERROR 1\n' + err);
        }   
    });

    socket.on('error', function(err) {
        console.log('Remote Control Server: ERROR 2\n' + err);
    });
});

remote_control_server.listen(3001);
console.log('Remote Control Server is running...');
