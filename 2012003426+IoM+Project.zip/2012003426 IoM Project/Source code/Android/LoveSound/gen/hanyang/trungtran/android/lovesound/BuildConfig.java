/** Automatically generated file. DO NOT MODIFY */
package hanyang.trungtran.android.lovesound;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}