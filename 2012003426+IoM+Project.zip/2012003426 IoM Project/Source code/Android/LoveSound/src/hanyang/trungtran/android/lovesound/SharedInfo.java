package hanyang.trungtran.android.lovesound;

import java.net.Socket;
import java.util.List;

public class SharedInfo {
	public static int PORT = 9999;
	
	public static String REMOTE_HOST = "128.199.196.138";
	public static int REMOTE_PORT = 9999;
	public static int REMOTE_CONTROL_PORT = 3001;
	public static String MY_ID = "";
	public static Socket REMOTE_SOCKET = null;
	public static Socket REMOTE_CONTROL_SOCKET = null;
	public static List<MBox> MBOX_LIST = null;
	public static MBox CONNECTED_MBOX = null;
	public static int LAST_MBOX = -1;
	public static boolean OK_TO_PLAY = true;
	public static boolean INIT_CHECK = true;
}
