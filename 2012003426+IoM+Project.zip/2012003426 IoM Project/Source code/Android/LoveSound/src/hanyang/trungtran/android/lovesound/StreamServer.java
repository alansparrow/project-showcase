package hanyang.trungtran.android.lovesound;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import android.util.Log;

public class StreamServer extends Thread {
	private ServerSocket serverSocket;

	public void run() {
		Socket socket = null;
		
		try {
			serverSocket = new ServerSocket(SharedInfo.PORT);
			
			while (true) {
				Log.d("DATA", "Waiting for client...");
				socket = serverSocket.accept();
				ClientPool.addClient(socket);
				Log.d("DATA", "New Connection");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
