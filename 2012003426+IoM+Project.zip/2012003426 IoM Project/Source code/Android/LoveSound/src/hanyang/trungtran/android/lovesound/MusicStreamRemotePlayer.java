package hanyang.trungtran.android.lovesound;

import java.io.BufferedInputStream;
import java.net.InetAddress;
import java.net.Socket;

import org.json.JSONObject;

import android.util.Log;

public class MusicStreamRemotePlayer extends Thread {
	private String host = "";
	private int port = 0;
	private Socket remoteSocket = null;

	public MusicStreamRemotePlayer(String remoteHost, int remotePort) {
		this.host = remoteHost;
		this.port = remotePort;
	}

	public void run() {
		try {
			remoteSocket = new Socket(InetAddress.getByName(host), port);

			BufferedInputStream inputStream = new BufferedInputStream(
					remoteSocket.getInputStream());
			while (remoteSocket != null) {
				if (SharedInfo.REMOTE_SOCKET == null) {
					SharedInfo.REMOTE_SOCKET = remoteSocket;
				}
				
				byte[] buffer = new byte[5000];
				inputStream.read(buffer);
				String myInfoStr = new String(buffer);
				myInfoStr = myInfoStr.trim();
				Log.d("CONN", "Received string: " + myInfoStr);
				JSONObject myInfoObj = new JSONObject(myInfoStr);

				SharedInfo.MY_ID = myInfoObj.getString("id");

				Log.d("CONN", "Received code: " + myInfoObj.get("code"));
				Log.d("CONN", "Connected to server as: " + SharedInfo.MY_ID);

				break;
			}

			if (!SharedInfo.MY_ID.equals("")) {
				ClientPool.addClient(remoteSocket);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}