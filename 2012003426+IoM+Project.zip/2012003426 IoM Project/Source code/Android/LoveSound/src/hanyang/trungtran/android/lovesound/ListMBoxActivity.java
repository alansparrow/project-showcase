package hanyang.trungtran.android.lovesound;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class ListMBoxActivity extends ActionBarActivity {
	private static final int FILE_SELECT_CODE = 0;
	private ListView mboxListView;
	private MBoxItemAdapter mAdapter;
	private MBox selectedMBox = null;
	private int selectedPos = -1;
	private Context ctx = null;
	private Button okBtn = null;
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			if (msg.what == 1) {
				MBoxItem mBoxItem = (MBoxItem) msg.obj;
				mAdapter.add(mBoxItem);

			} else if (msg.what == -1) {
				int pos = (Integer) msg.obj;

			} else if (msg.what == 0) {
				int pos = (Integer) msg.obj;
				mAdapter.clear();
				mAdapter.notifyDataSetChanged();
				getMBoxList();
			}
		}
	};
	Toast toast;

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_list_mbox);

		mboxListView = (ListView) findViewById(R.id.mbox_listview);
		okBtn = (Button) findViewById(R.id.ok_btn);
		okBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (SharedInfo.CONNECTED_MBOX == null) {
					if (toast != null) {
						toast.cancel();
					}
					Context context = getApplicationContext();
					CharSequence text = "Select a MBox!";
					int duration = Toast.LENGTH_SHORT;

					toast = Toast.makeText(context, text, duration);
					toast.show();
				} else {
					Intent musicPlayerActivity = new Intent(ctx,
							MusicPlayerActivity.class);
					startActivity(musicPlayerActivity);
				}
			}
		});
		ctx = this;

		mAdapter = new MBoxItemAdapter(this, R.layout.list_item);
		mboxListView.setAdapter(mAdapter);

		new ReadReply().start();
		getMBoxList();

		// mboxListView Item Click Listener
		mboxListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				selectedMBox = null;
				selectedPos = -1;
				// mboxListView Clicked item index
				int itemPosition = position;

				// mboxListView Clicked item value
				Log.d("CONN", "Pos: " + itemPosition);

				MBox mbox = SharedInfo.MBOX_LIST.get(itemPosition);

				if (!mbox.getStatus().equals("FREE")) {
					if (toast != null) {
						toast.cancel();
					}
					Context context = getApplicationContext();
					CharSequence text = "The MBox is busy!";
					int duration = Toast.LENGTH_SHORT;

					toast = Toast.makeText(context, text, duration);
					toast.show();
				} else {
					selectedMBox = mbox;
					selectedPos = itemPosition;
					getDisconnect();
					getConnect(mbox.getId());
				}
			}

		});
	}

	public void getConnect(String partner_id) {
		JSONObject obj = new JSONObject();
		try {
			obj.put("myid", SharedInfo.MY_ID);
			obj.put("partner_id", partner_id);
			obj.put("req_no", 2);

			String myReq = obj.toString();
			Log.d("CONN", myReq);

			OutputStream outputStream = SharedInfo.REMOTE_CONTROL_SOCKET
					.getOutputStream();

			outputStream.write(myReq.getBytes());
			outputStream.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void getDisconnect() {
		JSONObject obj = new JSONObject();
		try {
			obj.put("myid", SharedInfo.MY_ID);
			obj.put("partner_id", "null");
			obj.put("req_no", 3);

			String myReq = obj.toString();
			Log.d("CONN", myReq);

			OutputStream outputStream = SharedInfo.REMOTE_CONTROL_SOCKET
					.getOutputStream();

			outputStream.write(myReq.getBytes());
			outputStream.flush();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void getMBoxList() {
		JSONObject obj = new JSONObject();
		try {
			obj.put("myid", SharedInfo.MY_ID);
			obj.put("partner_id", "null");
			obj.put("req_no", 1);

			String myReq = obj.toString();
			Log.d("CONN", myReq);

			OutputStream outputStream = SharedInfo.REMOTE_CONTROL_SOCKET
					.getOutputStream();

			outputStream.write(myReq.getBytes());
			outputStream.flush();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private class ReadReply extends Thread {
		public ReadReply() {

		}

		public void run() {
			try {

				while (true) {

					BufferedInputStream inputStream = new BufferedInputStream(
							SharedInfo.REMOTE_CONTROL_SOCKET.getInputStream());
					byte[] buffer = new byte[5000];
					Log.d("CONN", "Wait here");
					inputStream.read(buffer);
					String replyStr = new String(buffer);
					replyStr = replyStr.trim();
					Log.d("CONN", "Received string from control server: "
							+ replyStr);
					JSONObject replyObj = new JSONObject(replyStr);

					String statusStr = replyObj.get("status").toString();
					int req_no = (Integer) replyObj.get("req_no");

					Log.d("CONN", "Req No: " + req_no);
					Log.d("CONN", "Status: " + statusStr);

					switch (req_no) {
					case 1:
						if (statusStr.equals("OK")) {
							Log.d("CONN", "jMBoxList: " + "null");
							SharedInfo.MBOX_LIST = new ArrayList<MBox>();

							String tmpStr = replyObj.get("data").toString();
							JSONArray jMBoxList = new JSONArray(tmpStr);

							Log.d("CONN", "jMBoxList: " + jMBoxList);

							for (int i = 0; i < jMBoxList.length(); i++) {
								Log.d("CONN", "Index: " + i);
								JSONObject obj = jMBoxList.getJSONObject(i);
								MBox mbox = new MBox(obj.get("id").toString(),
										obj.get("status").toString());
								SharedInfo.MBOX_LIST.add(mbox);

								String partnerID = "";
								if (SharedInfo.CONNECTED_MBOX != null) {
									partnerID = SharedInfo.CONNECTED_MBOX
											.getId();
								}

								MBoxItem mBoxItem = new MBoxItem(
										mbox.getId(),
										mbox.getStatus().equals("FREE") ? R.drawable.music_off
												: R.drawable.music_on,
										mbox.getId().equals(partnerID) ? R.drawable.connected
												: -1);

								/*
								 * MBoxItem mBoxItem = new MBoxItem();
								 * mBoxItem.setMboxID(mbox.getId()); if
								 * (mbox.getStatus().equals("FREE")) {
								 * mBoxItem.setImgStatus(R.drawable.music_off);
								 * } else {
								 * mBoxItem.setImgStatus(R.drawable.music_on); }
								 * if (mbox.getId().equals(partnerID)) {
								 * mBoxItem
								 * .setImgConnectStatus(R.drawable.connected); }
								 * else { mBoxItem.setImgConnectStatus(-1); }
								 * 
								 * Log.d("CONN", "ID: " + mBoxItem.getMboxID() +
								 * "   Status IMG: " + mBoxItem.getImgStatus() +
								 * "   Connect Status IMG: " + mBoxItem
								 * .getImgConnectStatus());
								 */

								Message msg = handler.obtainMessage(1);
								msg.obj = mBoxItem;
								msg.sendToTarget();
							}
						}
						break;
					case 2:
						if (statusStr.equals("OK")) {
							SharedInfo.CONNECTED_MBOX = selectedMBox;
							String tmpStr = replyObj.get("data").toString();
							JSONObject jObj = new JSONObject(tmpStr);
							String mid = jObj.get("mid").toString();
							String sid = jObj.get("sid").toString();

							Log.d("CONN", "CONNECTED_MBOX: "
									+ SharedInfo.CONNECTED_MBOX.getId());

							Message msg = handler.obtainMessage(0);
							msg.obj = (Integer) selectedPos;
							msg.sendToTarget();
						}
						break;
					case 3:
						if (statusStr.equals("OK")) {
							SharedInfo.CONNECTED_MBOX = null;
							if (SharedInfo.LAST_MBOX != -1) {
								Message msg = handler.obtainMessage(-1);
								msg.obj = (Integer) SharedInfo.LAST_MBOX;
								msg.sendToTarget();
							}
						}
						break;
					default:
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
