package hanyang.trungtran.android.lovesound;

import java.net.Socket;

public class MusicStreamRemoteController extends Thread {
	private String host = "";
	private int port = 0;
	private static Socket remoteSocket = null;
	private int reqNo = -1;
	private String data = "";

	public MusicStreamRemoteController(int reqNo, String data) {
		this.reqNo = reqNo;
		this.data = data;
	}

	public MusicStreamRemoteController(String remoteHost, int remotePort) {
		this.host = remoteHost;
		this.port = remotePort;
	}

	public void run() {
		switch (reqNo) {
		case -1:
			break;
		case 1:
			break;
		case 2:
			break;
		default:
			break;
		}
	}
}
