package hanyang.trungtran.android.lovesound;

import java.io.BufferedInputStream;
import java.net.InetAddress;
import java.net.Socket;

import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class LogIn extends ActionBarActivity implements OnClickListener {
	private Button con_btn = null;
	private ImageView dis_con_img = null;
	private TextView con_status_txt = null;
	private Context myContext = null;

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			if (msg.what == 0) {
				con_btn.setEnabled(true);
				con_btn.setVisibility(View.VISIBLE);
				dis_con_img.setEnabled(true);
				dis_con_img.setVisibility(View.VISIBLE);
				con_status_txt.setGravity(Gravity.CENTER);
				con_status_txt.setText("Cannot connect to Server\n Try again");
			} else if (msg.what == 1) {
				con_btn.setEnabled(false);
				con_btn.setVisibility(View.INVISIBLE);
				dis_con_img.setImageResource(R.drawable.success);
				con_status_txt.setGravity(Gravity.CENTER);
				con_status_txt.setText("Connected");

				try {
					Thread.sleep(2000);
					Intent mboxListActivity = new Intent(myContext,
							ListMBoxActivity.class);
					startActivity(mboxListActivity);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_log_in);

		con_btn = (Button) findViewById(R.id.con_btn);
		dis_con_img = (ImageView) findViewById(R.id.discon_img);
		con_status_txt = (TextView) findViewById(R.id.con_status_txt);
		myContext = this;

		con_btn.setOnClickListener(this);

		Message msg = handler.obtainMessage(0);
		msg.sendToTarget();
		new ConnectThread().start();
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		new ConnectThread().start();
	}

	private class ConnectThread extends Thread {
		Socket remoteSocket = null;
		Socket remoteControlSocket = null;

		public ConnectThread() {

		}

		public void run() {
			try {
				remoteSocket = new Socket(
						InetAddress.getByName(SharedInfo.REMOTE_HOST),
						SharedInfo.REMOTE_PORT);
				remoteControlSocket = new Socket(
						InetAddress.getByName(SharedInfo.REMOTE_HOST),
						SharedInfo.REMOTE_CONTROL_PORT);

				SharedInfo.REMOTE_SOCKET = remoteSocket;
				SharedInfo.REMOTE_CONTROL_SOCKET = remoteControlSocket;

				getMyInfo();

				Message msg = handler.obtainMessage(1);
				msg.sendToTarget();

			} catch (Exception e) {
				Message msg = handler.obtainMessage(0);
				msg.sendToTarget();

				e.printStackTrace();
			}
		}

		public void getMyInfo() {
			try {
				BufferedInputStream inputStream = new BufferedInputStream(
						remoteSocket.getInputStream());
				byte[] buffer = new byte[5000];
				inputStream.read(buffer);
				String myInfoStr = new String(buffer);
				myInfoStr = myInfoStr.trim();
				Log.d("CONN", "Received string: " + myInfoStr);
				JSONObject myInfoObj = new JSONObject(myInfoStr);

				SharedInfo.MY_ID = myInfoObj.getString("id");

				Log.d("CONN", "Received code: " + myInfoObj.get("code"));
				Log.d("CONN", "Connected to server as: " + SharedInfo.MY_ID);

				if (!SharedInfo.MY_ID.equals("")) {
					ClientPool.addClient(remoteSocket);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
