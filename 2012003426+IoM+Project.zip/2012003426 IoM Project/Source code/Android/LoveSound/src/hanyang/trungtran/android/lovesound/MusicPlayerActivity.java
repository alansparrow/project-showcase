package hanyang.trungtran.android.lovesound;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;

public class MusicPlayerActivity extends ActionBarActivity implements
		OnPreparedListener, MediaController.MediaPlayerControl {
	private static final int READ_REQUEST_CODE = 42;

	MediaPlayer mediaPlayer;
	MediaController mediaController;
	Handler handler;
	InputStream dataFile;
	ReadFile rfHandler1 = null;
	ReadFile rfHandler2 = null;
	Uri uri;
	TextView selectTxt;
	TextView guideTxt;
	Context ctx;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		ctx = this;
		selectTxt = (TextView) findViewById(R.id.select_text);
		guideTxt = (TextView) findViewById(R.id.guide_text);
		
		selectTxt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showFileChooser();
			}
		});

	}

	private void showFileChooser() {

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		intent.setType("audio/*");

		startActivityForResult(intent, READ_REQUEST_CODE);

	}

	@Override
	public void onActivityResult(int requestCode, int resultCode,
			Intent resultData) {

		// The ACTION_OPEN_DOCUMENT intent was sent with the request code
		// READ_REQUEST_CODE. If the request code seen here doesn't match, it's
		// the
		// response to some other intent, and the code below shouldn't run at
		// all.

		if (requestCode == READ_REQUEST_CODE && resultCode == RESULT_OK) {
			// The document selected by the user won't be returned in the
			// intent.
			// Instead, a URI to that document will be contained in the return
			// intent
			// provided to this method as a parameter.
			// Pull that URI using resultData.getData().
			if (resultData != null) {
				uri = resultData.getData();
				Log.i("CONN", "Uri: " + uri.toString());

				try {

					dataFile = getContentResolver().openInputStream(uri);

					Log.i("CONN", "Input avail: " + dataFile.available());

					if (dataFile != null) {

						Log.d("CONN", "New Song");

						if (mediaPlayer != null) {
							mediaPlayer.stop();
						}

						mediaPlayer = null;
						mediaController = null;
						handler = null;

						mediaPlayer = new MediaPlayer();
						mediaController = new MediaController(this);
						handler = new Handler();

						SharedInfo.OK_TO_PLAY = true;
						new MusicStreamServerPlayer(this).start();

						if (rfHandler1 == null) {
							if (rfHandler2 != null) {
								rfHandler2.setFinished(true);
								rfHandler2 = null;
							}
							rfHandler1 = new ReadFile(dataFile, uri);
							rfHandler1.start();
						} else if (rfHandler2 == null) {
							if (rfHandler1 != null) {
								rfHandler1.setFinished(true);
								rfHandler1 = null;
							}
							rfHandler2 = new ReadFile(dataFile, uri);
							rfHandler2.start();
						}

					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		mediaPlayer = null;
		mediaController = null;
		handler = null;

		dataFile = null;
		uri = null;

		if (rfHandler1 != null) {
			rfHandler1.setFinished(true);
		}
		if (rfHandler2 != null) {
			rfHandler2.setFinished(true);
		}

		rfHandler1 = null;
		rfHandler2 = null;
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	private class MusicStreamServerPlayer extends Thread {
		private MusicPlayerActivity ctx;

		public MusicStreamServerPlayer(MusicPlayerActivity ctx) {
			this.ctx = ctx;
		}

		public void run() {
			try {
				mediaPlayer.setOnPreparedListener(ctx);
				mediaPlayer.setDataSource(ctx, uri);
				mediaPlayer.prepareAsync();

			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private class ReadFile extends Thread {
		private boolean isFinished = false;
		private InputStream inStream = null;
		private Uri songUri = null;
		private int file_duration = 0;
		private int pos_old = 0;
		private int pos_new = 0;

		public ReadFile(InputStream inStream, Uri songUri) {
			this.inStream = inStream;
			this.songUri = songUri;

			try {
				this.file_duration = inStream.available();
				Log.d("SB", "File duration: " + this.file_duration);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public void setFinished(boolean isFinished) {
			this.isFinished = isFinished;
		}

		public void seekTo(float posInPercent) {
			pos_new = (int) (file_duration * posInPercent);
			Log.d("DATA", "pos_new: " + pos_new);
		}

		public void stream() {
			try {

				while (isFinished == false && inStream.available() != 0) {

					if (pos_new != pos_old) {
						inStream = getContentResolver()
								.openInputStream(songUri);
						inStream.skip(pos_new);
						pos_old = pos_new;
					}
					if (mediaPlayer.isPlaying() == true) {
						byte[] buffer = new byte[16050];
						inStream.read(buffer);
						Log.d("DATA", "" + inStream.available());
						ClientPool.broadcast(buffer);
					}

					Thread.sleep(1000);
				}

				Log.d("FNS", "Finish a song");
				// mediaPlayer.stop();

			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (inStream != null)
						inStream.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}

		public void run() {
			stream();
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		if (mediaController != null) {
			mediaController.hide();
			SharedInfo.INIT_CHECK = true;
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// the MediaController will hide after 3 seconds - tap the screen to
		// make it appear again
		if (mediaController != null) {
			if (SharedInfo.INIT_CHECK == true) {
				try {
					Thread.sleep(0);
					SharedInfo.INIT_CHECK = false;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			mediaController.show();
		}

		return false;
	}

	@Override
	public boolean canPause() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean canSeekBackward() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean canSeekForward() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getAudioSessionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getBufferPercentage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCurrentPosition() {
		// TODO Auto-generated method stub
		return mediaPlayer.getCurrentPosition();
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return mediaPlayer.getDuration();
	}

	@Override
	public boolean isPlaying() {
		// TODO Auto-generated method stub
		return mediaPlayer.isPlaying();
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		mediaPlayer.pause();
	}

	@Override
	public void seekTo(int arg0) {
		// TODO Auto-generated method stub
		mediaPlayer.seekTo(arg0);
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		mediaPlayer.start();
	}

	@Override
	public void onPrepared(MediaPlayer arg0) {
		Log.d("DATA", "Prepared!");
		mediaController.setMediaPlayer(this);
		mediaController.setAnchorView(findViewById(R.id.LinearLayout1));

		final int topContainerId1 = getResources().getIdentifier(
				"mediacontroller_progress", "id", "android");
		final SeekBar seekbar = (SeekBar) mediaController
				.findViewById(topContainerId1);

		seekbar.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				float posInPercent = (float) (mediaPlayer.getCurrentPosition() / (0.0 + mediaPlayer
						.getDuration()));
				Log.d("SB", "Seekbar clicked: " + posInPercent);

				if (rfHandler1 != null) {
					rfHandler1.seekTo(posInPercent);
				} else if (rfHandler2 != null) {
					rfHandler2.seekTo(posInPercent);
				}

				return false;
			}
		});

		handler.post(new Runnable() {
			public void run() {
				SharedInfo.OK_TO_PLAY = true;
			}
		});
	}
}
