package hanyang.trungtran.android.lovesound;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;

public class EntryActivity extends ActionBarActivity {
	Handler handler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_entry);

		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);

			}
		};

		new MusicStreamRemotePlayer(SharedInfo.REMOTE_HOST, SharedInfo.PORT)
				.start();
	}

	private class RemoteControl extends Thread {
		private int cmdNo;
		private String data;

		public RemoteControl(int cmdNo, String data) {
			this.cmdNo = cmdNo;
			this.data = data;
		}

		public void run() {
			switch (cmdNo) {
			case 0:
				break;
			case 1:
				break;
			default:
				break;
			}
		}
	}
}
