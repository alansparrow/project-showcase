package hanyang.trungtran.android.lovesound;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MBoxItemAdapter extends ArrayAdapter<MBoxItem> {

	private Context mCtx;
	private LayoutInflater mInflayer;
	private String className;

	public MBoxItemAdapter(Context context, int resource) {
		super(context, resource);
		// TODO Auto-generated constructor stub
		this.mCtx = context;
		this.className = context.getClass().getSimpleName();
		this.mInflayer = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		MBoxItem mItem = getItem(position);
		ItemHolder mHolder = null;

		if (convertView == null) {
			convertView = mInflayer.inflate(R.layout.list_item, parent, false);
			mHolder = new ItemHolder();
			mHolder.mTextID = (TextView) convertView
					.findViewById(R.id.textViewID);
			mHolder.mImgStatus = (ImageView) convertView
					.findViewById(R.id.imageViewStatus);
			mHolder.mImgConnectStatus = (ImageView) convertView
					.findViewById(R.id.imageViewConnectStatus);
			
			convertView.setTag(mHolder);
		} else {
			mHolder = (ItemHolder) convertView.getTag();
		}
		mHolder.mTextID.setText(mItem.getMboxID());
		mHolder.mImgStatus.setImageResource((mItem.getImgStatus()));
		mHolder.mImgConnectStatus.setImageResource((mItem.getImgConnectStatus()));

		return convertView;
	}

	private class ItemHolder {
		TextView mTextID;
		ImageView mImgStatus;
		ImageView mImgConnectStatus;
	}

}
