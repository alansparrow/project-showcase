package hanyang.trungtran.android.lovesound;

public class MBoxItem {

	public String mboxID;
	public int imgStatus;
	public int imgConnectStatus;
	
	public MBoxItem(String mboxID, int imgStatus, int imgConnectStatus) {
		super();
		this.mboxID = mboxID;
		this.imgStatus = imgStatus;
		this.imgConnectStatus = imgConnectStatus;
	}

	public MBoxItem() {
		// TODO Auto-generated constructor stub
	}

	public String getMboxID() {
		return mboxID;
	}

	public void setMboxID(String mboxID) {
		this.mboxID = mboxID;
	}

	public int getImgStatus() {
		return imgStatus;
	}

	public void setImgStatus(int imgStatus) {
		this.imgStatus = imgStatus;
	}

	public int getImgConnectStatus() {
		return imgConnectStatus;
	}

	public void setImgConnectStatus(int imgConnectStatus) {
		this.imgConnectStatus = imgConnectStatus;
	}
}
