package hanyang.trungtran.android.lovesound;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ClientPool {
	public static List<Socket> clientList = new ArrayList<Socket>();

	public static void addClient(Socket socket) {
		clientList.add(socket);	
	}
	
	public static void removeClient(Socket socket) {
		clientList.remove(socket);
	}
	
	public static void broadcast(byte[] data) {
		for (Socket socket : clientList) {
			try {
				if ((socket != null) && (socket.getOutputStream() != null)) {
					socket.getOutputStream().write(data);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ClientPool.removeClient(socket);
			}
		}
	}
}
